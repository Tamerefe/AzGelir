# AzGelir Portable Sürüm

## Kullanım
1. `AzGelir_Baslat.bat` dosyasını çalıştırın
2. Veya doğrudan `AzGelir.exe` dosyasını çalıştırın

## Özellikler
- Kurulum gerektirmez
- USB bellekte taşınabilir
- Sistem kayıtlarını değiştirmez
- Veriler aynı klasörde saklanır

## Sistem Gereksinimleri
- Windows 7 SP1 veya üzeri
- .NET Framework 4.6.1 veya üzeri

Tüm veriler bu klasörde tutulur. Klasörü kopyalayarak 
uygulamayı başka bilgisayarlara taşıyabilirsiniz.
